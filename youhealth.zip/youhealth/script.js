const chatBox = document.getElementById("chat-box");
const userInputElement = document.getElementById("user-input");

// تعريف متغير لحفظ النص المحول من الصوت إلى كلام
let convertedText = "";

const recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
recognition.lang = "ar-SA"; // تحديد لغة التعرف على الصوت إلى اللغة العربية

recognition.interimResults = false;
recognition.maxAlternatives = 1;

recognition.onstart = () => {
    console.log("Voice recognition started");
};

recognition.onresult = (event) => {
    const transcript = event.results[0][0].transcript;
    appendMessage("user", transcript);

    // حفظ النص المحول في المتغير
    convertedText = transcript;

    // تحويل النص إلى كلام باللغة العربية وتشغيله
    speakArabicWithDelay(transcript);
};

recognition.onerror = (event) => {
    console.error("Voice recognition error", event.error);
};

recognition.onend = () => {
    console.log("Voice recognition ended");
};

// دالة لتشغيل الكلام باللغة العربية
function speakArabic(text) {
    // تحويل النص إلى كلام باللغة العربية وتشغيله
    // يمكنك استخدام خدمات Text-to-Speech المناسبة
}

// دالة لتحويل النص إلى كلام مع تأخير
function speakArabicWithDelay(text) {
    // تحويل النص إلى كلام باللغة العربية وتشغيله
    // يمكنك استخدام خدمات Text-to-Speech المناسبة
    // ثم تطبيق تأخير باستخدام setTimeout
    speakArabic(text); // ابدأ تحويل النص إلى كلام

    // تأخير لمدة 5 ثوانٍ قبل تشغيل الكلام
    setTimeout(() => {
        // انقل هنا الشفرة لتشغيل الكلام بعد انقضاء الوقت المحدد
    }, 2000);
}

// دالة لإضافة رسالة إلى نافذة الدردشة
function appendMessage(sender, message) {
    const messageElement = document.createElement("div");
    messageElement.classList.add("message", sender);
    messageElement.textContent = message;
    chatBox.appendChild(messageElement);
    chatBox.scrollTop = chatBox.scrollHeight;
}

// استمع إلى زر الصوت عند النقر
const startButton = document.getElementById("Voice-button");
startButton.addEventListener("click", startVoiceChat);

function startVoiceChat() {
    recognition.start();
}

// استمع إلى الضغط على زر الإرسال
const sendButton = document.getElementById("send-btn");
sendButton.addEventListener("click", () => {
    // قم بإرسال النص المحول إلى الشات بعد الضغط على زر الإرسال
    appendMessage("user", userInputElement.value);
    userInputElement.value = "";

    // قم بإرسال النص المحول إلى الشات
    appendMessage("user", convertedText);

    // يمكنك أيضًا استخدام convertedText كنص للرسالة وإرسالها إلى الشات بدلاً من قيمة الإدخال
    convertedText = ""; // إعادة تعيين النص المحول بعد الإرسال
});